<?php

namespace App\Models;

class Project extends BaseElement {

}